<?php

namespace Cloudinary\Api;

class GeneralError extends Error
{
}
