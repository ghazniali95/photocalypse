<?php

namespace Cloudinary\Api;

class Error extends \Exception
{
}
