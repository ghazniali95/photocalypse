<?php

namespace Cloudinary;

class Error extends \Exception
{
}
