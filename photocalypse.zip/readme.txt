Made by:

Syed Ghazanfar Ali
FA15-BCS-079
6B

M Ammar Qureshi
FA15-BCS-053

Description:
The website is made in custom PHP with MVC implemented. This website will use cloud for storing images and media, Will use microsoft image recognizer to detect faces
detect gender and age. You can make your own account and share your images with your friends and followers.

Live Link:
The website is also live on http://photocalypse.mesh99.com/