<?php
include("../../../config.php");
defined("ACCESS") or die("Direct Access Forbidden");
include("../../lib/class.db.php");
?>