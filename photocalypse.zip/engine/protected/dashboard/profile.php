<?php
ini_set('max_execution_time', 300);
include("../config.php");
defined("ACCESS") or die("Direct Access Forbidden");
if(isset($_POST['update_prof'])) {
	try {
		require '../../../scripts/cloudinary/Cloudinary.php';
		require '../../../scripts/cloudinary/Uploader.php';
		require '../../../scripts/cloudinary/Api.php';
		include("../../lib/class.cloud.php");
		$con = new DB();
		

		if(!empty($_FILES['profile']['name'])) {
			$file = new Cloud();
			$cloud_res = $file->upload($_FILES['profile']['tmp_name']);

			$con->query("UPDATE " . prefix . "profile SET profile_url=:profile_url WHERE id = :id LIMIT 1");
			$con->exec(
				array(
					":profile_url" => $cloud_res['url'],
					":id" => $_SESSION['user']['id']
				)
			);



			//face detection algorithm / class
			require_once "../../../scripts/HTTP/Request2.php";
			include("../../lib/class.facedetect.php");
			$newFace = new FaceDetect();
			$faceData = $newFace->detect($cloud_res['url']);
			



			if(sizeof($faceData) > 1) {
				$_SESSION['error'] = "Your Image contain " . sizeof($faceData) . " Faces please select image that has only one face";
				header("location:../../../index.php?route=dashboard/profile");
				exit();
			}

			$_SESSION['imageDet'] = $faceData;

			$_SESSION['user']['profile_url'] = $cloud_res['url'];
		}

		//update for password
		if(!empty($_POST['newpass']) && !empty($_POST['newpassagain'])) {
			$con->query("UPDATE " . prefix . "profile SET fname=:fname, lname=:lname, occupation=:occupation, description=:description, university=:university, country=:country, city=:city WHERE id = :id LIMIT 1");
			$con->exec(
				array(
					":fname" => $_POST['fname'],
					":lname" => $_POST['lname'],
					":occupation" => $_POST['occupation'],
					":description" => $_POST['description'],
					":university" => $_POST['university'],
					":country" => $_POST['country'],
					":city" => $_POST['city'],
					":id" => $_SESSION['user']['id']
				)
			);
		}

		//validate for already exist username, phone, email
		$con->query("UPDATE " . prefix . "profile SET fname=:fname, lname=:lname, occupation=:occupation, description=:description, university=:university, country=:country, city=:city WHERE id = :id LIMIT 1");
		$con->exec(
			array(
				":fname" => $_POST['fname'],
				":lname" => $_POST['lname'],
				":occupation" => $_POST['occupation'],
				":description" => $_POST['description'],
				":university" => $_POST['university'],
				":country" => $_POST['country'],
				":city" => $_POST['city'],
				":id" => $_SESSION['user']['id']
			)
		);
		$_SESSION['success'] = "Successfully Updated";
		header("location:../../../index.php?route=dashboard/profile");
		exit();

	}
	catch(exception $e) {
		echo "There might be some problem <a href='../../../index.php'>click here</a> to go to main site" . $e;
	}
}
?>