<?php
include("../config.php");
defined("ACCESS") or die("Direct Access Forbidden");
if(isset($_POST['update_prof'])) {
	try {
		$con = new DB();
		$con->query("SELECT * FROM ");

		$_SESSION['success'] = "Successfully Updated";
		header("location:../../../index.php?route=dashboard/profile");
		exit();

	}
	catch(exception $e) {
		echo "There might be some problem <a href='../../../index.php'>click here</a> to go to main site" . $e;
	}
}
?>