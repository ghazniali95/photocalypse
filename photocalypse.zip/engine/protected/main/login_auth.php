<?php
include("../config.php");
defined("ACCESS") or die("Direct Access Forbidden");
if(isset($_POST['login_auth'])) {
	try {
		$con = new DB();
		
		//validate for already exist username, phone, email
		$con->query("SELECT id, username, fname, lname, profile_url FROM " . prefix . "profile WHERE username = :username AND password = :password LIMIT 1");
		$con->exec(
			array(
				":username" => $_POST['username'],
				":password" => $_POST['password']
			)
		);

		//fetch data and set sessions
		$data = $con->fetch();
		foreach($data as $row) {
			$_SESSION['user']['id'] = $row['id'];
			$_SESSION['user']['username'] = $row['username'];
			$_SESSION['user']['fname'] = $row['fname'];
			$_SESSION['user']['lname'] = $row['lname'];
			$_SESSION['user']['profile_url'] = $row['profile_url'];

			$_SESSION['success'] = "Successfully logged In";
			header("location:../../../index.php?route=dashboard/dashboard");
			exit();
		}

		$_SESSION['error'] = "Sorry your credentials are incorrect!";
		
		header("location:../../../index.php?main/main");

	}
	catch(exception $e) {
		echo "There might be some problem <a href='../../../index.php'>click here</a> to go to main site" . $e;
	}
}
?>