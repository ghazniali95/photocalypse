<?php
include("../config.php");
defined("ACCESS") or die("Direct Access Forbidden");
if(isset($_POST['register'])) {
	try {
		require '../../../scripts/cloudinary/Cloudinary.php';
		require '../../../scripts/cloudinary/Uploader.php';
		require '../../../scripts/cloudinary/Api.php';
		include("../../lib/class.cloud.php");

		$con = new DB();

		$file = new Cloud();
		$cloud_res = $file->upload($_POST['profileData']);
		//validate for already exist username, phone, email
		$con->query("SELECT username, email, phone FROM " . prefix . "profile WHERE email = :email OR phone = :phone OR username = :username LIMIT 1");
		$con->exec(
			array(
				":email" => $_POST['email'],
				":phone" => $_POST['phone'],
				":username" => $_POST['username']
			)
		);

		//backend validation
		if(sizeof($con->fetch()) > 0) {
			$_SESSION['error'] = "Username, Email or Phone is taken!";
			header("location:../../../index.php?route=main/main");
			exit();
		}
		
		if(empty($_POST['username']) || empty($_POST['password']) || empty($_POST['fname']) || empty($_POST['lname']) || empty($_POST['email']) || empty($_POST['phone'])) {
			$_SESSION['error'] = "Please fill all the fields!";
			header("location:../../../index.php?route=main/main");
			exit();
		}

		//make salt for login secure
		$salt = uniqid(mt_rand(), true);

		//Every thing is good proceed for insertion
		$con->query("INSERT INTO " . prefix . "profile (username, password, salt, fname, lname, profile_url, email, phone, status) VALUES (:username, :password, :salt, :fname, :lname, :profile_url, :email, :phone, :status)");
		$con->exec(
			array(
				":username" => $_POST['username'],
				":password" => $_POST['password'],
				":salt" => $salt,
				":fname" => $_POST['fname'],
				":lname" => $_POST['lname'],
				":profile_url" => $cloud_res['url'],
				":email" => $_POST['email'],
				":phone" => $_POST['phone'],
				":status" => 0
			)
		);

		$code = mt_rand();

		$body = '
			Your Verification code is 
		' . $code;
		$_SESSION['vcode'] = $code;
		if(mail($_POST['email'], "Authenticate your Email - Photocalypse", $body)) {

		}

		/*
				##### login #####
		*/

		//validate for already exist username, phone, email
		$con->query("SELECT id, username, fname, lname FROM " . prefix . "profile WHERE username = :username AND password = :password LIMIT 1");
		$con->exec(
			array(
				":username" => $_POST['username'],
				":password" => $_POST['password']
			)
		);

		//fetch data and set sessions
		$data = $con->fetch();
		foreach($data as $row) {
			$_SESSION['user']['id'] = $row['id'];
			$_SESSION['user']['username'] = $row['username'];
			$_SESSION['user']['fname'] = $row['fname'];
			$_SESSION['user']['lname'] = $row['lname'];

			$_SESSION['user']['profile_url'] = $cloud_res['url'];

			$_SESSION['success'] = "Successfully logged In";
			header("location:../../../index.php?route=main/verify");
			exit();
		}

		$_SESSION['error'] = "Login Error Please Login";
		header("location:../../../index.php?route=main/main");
		exit();

	}
	catch(exception $e) {
		echo "There might be some problem <a href='../../../index.php'>click here</a> to go to main site" . $e;
	}
}
?>