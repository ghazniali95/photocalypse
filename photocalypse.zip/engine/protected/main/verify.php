<?php
include("../config.php");
defined("ACCESS") or die("Direct Access Forbidden");
if(isset($_POST['verify'])) {
	try {
		$con = new DB();
		//verify
		if(strip_tags($_POST['vcode']) == $_SESSION['vcode']) {
			echo "code verified";
			$con->query("UPDATE " . prefix . "profile SET status = 1 WHERE id = :id");
			$con->exec(
				array(
					":id" => $_SESSION['user']['id']
				)
			);
			$_SESSION['success'] = "verified";
			header("location:../../../index.php?route=dashboard/dashboard");
		}
		else {
			$_SESSION['error'] = "Code did not matched";
			header("location:../../../index.php?route=main/verify");
		}

	}
	catch(exception $e) {
		echo "There might be some problem <a href='../../../index.php'>click here</a> to go to main site" . $e;
	}
}
?>