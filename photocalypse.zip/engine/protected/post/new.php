<?php
ini_set('max_execution_time', 800);
include("../config.php");
defined("ACCESS") or die("Direct Access Forbidden");
if(isset($_POST['upload_post'])) {
	try {
		require '../../../scripts/cloudinary/Cloudinary.php';
		require '../../../scripts/cloudinary/Uploader.php';
		require '../../../scripts/cloudinary/Api.php';
		include("../../lib/class.cloud.php");
		$con = new DB();
		$file = new Cloud();

		//upload Post
			$con->query("INSERT INTO " . prefix . "post (title, description, state, visibility, post_views, tags, thumbnail, og_title, og_description, status) VALUES (:title, :description, :state, :visibility, :post_views, :tags, :thumbnail, :og_title, :og_description, :status)");
			$con->exec(
				array(
					":title" => $_POST['title'],
					":description" => $_POST['description'],
					":state" => $_POST['state'],
					":visibility" => 1,
					":post_views" => 0,
					":tags" => $_POST['tags'],
					":thumbnail" => "",
					":og_title" => $_POST['title'],
					":og_description" => $_POST['description'],
					":status" => 1
				)
			);

			$con->query("SELECT id FROM " . prefix . "post ORDER BY id DESC LIMIT 1");
			$con->exec(array());
			$id = $con->fetch();

			$con->query("INSERT INTO " . prefix . "pp (profile_id, post_id, status) VALUES (:profile_id, :post_id, :status)");
			$con->exec(
				array(
					":profile_id" => $_SESSION['user']['id'],
					":post_id" => $id[0][0],
					":status" => 1
				)
			);

		foreach($_FILES['files']['tmp_name'] as $tmp) {
			//upload images
			$cloud_res = $file->upload($tmp);
			
			//save data in db
			$con->query("INSERT INTO " . prefix . "media (post_id, public_id, version, width, height, format, bytes, url, secure_url, status) VALUES (:post_id, :public_id, :version, :width, :height, :format, :bytes, :url, :secure_url, :status)");
			$con->exec(
				array(
					":post_id" => $id[0][0],
					":public_id" => $cloud_res['public_id'],
					":version" => $cloud_res['version'],
					":width" => $cloud_res['width'],
					"height" => $cloud_res['height'],
					"format" => $cloud_res['format'],
					":bytes" => $cloud_res['bytes'],
					":url" => $cloud_res['url'],
					":secure_url" => $cloud_res['secure_url'],
					":status" => 1
				)
			);
			sleep(3);
		}
		$_SESSION['success'] = "Success!";
		header("location:../../../index.php?route=post/new");
		exit();

	}
	catch(exception $e) {
		echo "There might be some problem <a href='../../../index.php'>click here</a> to go to main site this error may occure due to so many images upload or internet problem" . $e;
	}
}
?>