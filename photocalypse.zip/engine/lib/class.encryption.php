<?php
class Encryption {
	
	public function __construct() {
	}
	
	public function encode($value) {
		return base64_encode(base64_encode($value));
	}
	
	public function decode($value) {
		return base64_decode(base64_decode($value));
	}
}
?>