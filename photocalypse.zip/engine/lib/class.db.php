<?php
/*
* Date Created	:	15-07-2016
* Author		:	Ghazni ali (ghazniali95@gmail.com)
*/

class DB {
	private		$dbDriver;
	private		$dbHostname;
	private		$dbUsername;
	private		$dbPassword;
	private		$dbName;
	private		$dbPort;
	private 	$stmt;
	protected	$conn;

	public function __construct() {
		$this->dbDriver     =   DB_DRIVER;
		$this->dbHostname   =   DB_HOST;
		$this->dbUsername   =   DB_USERNAME;
		$this->dbPassword   =   DB_PASSWORD;
		$this->dbName       =   DB_NAME;
		$this->dbPort       =   DB_PORT;
	}
	
	public function newConn($dbHost, $dbUser, $dbPass, $dbName) {
		$this->dbHostname   =   $dbHost;
		$this->dbUsername   =   $dbUser;
		$this->dbPassword   =   $dbPass;
		$this->dbName       =   $dbName;
	}
	
	public function connectDB() {
		try {
		  $this->conn = new PDO("$this->dbDriver:host=$this->dbHostname;dbname=$this->dbName", $this->dbUsername, $this->dbPassword);
		  $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		catch(PDOException $e) {
		   echo "Connection failed: " . $e->getMessage();
		}
  	}
	
	public function closeDB() {
		$this->conn = null;
	}
	
	public function insertData($istmt) {
		try {
			$this->connectDB();
			$this->conn->exec($istmt);
			$id = $this->conn->lastInsertId();
			$this->closeDB();
			return $id;
		} catch(PDOExecption $e) {
			echo "<script>alert('Database Error : " . $e->getMessage() . "')</script>";
			return 0;
		}
	}
	
	public function updateData($istmt) {
		try {
			$this->connectDB();
			$query = $this->conn->prepare($istmt);
			$query->execute();
			return 1;
		} catch(PDOException $e) {
			echo "<script>alert('Database Error : " . $e->getMessage() . "')</script>";
			return 0;
		}
	}
	
	public function selectData($istmt) {
		try {
			$this->connectDB();
			$data = $this->conn->query($istmt);
			return $data;
		} catch(PDOExecption $e) {
			echo "<script>alert('Database Error : " . $e->getMessage() . "')</script>";
			return 0;
		}
	}
	
	public function insertMultiData($istmt, $getDataValues, $getData) {
		try {
			//connecting to database/making object
			$this->connectDB();
			
			//preparing statement for execution
			$DataValuesSize = sizeof($getDataValues);
			$prepareStmt = $istmt . " VALUES (";
			for($i=0; $i<$DataValuesSize; $i++) {
				if($i != ($DataValuesSize - 1))
					$prepareStmt .= $getDataValues[$i] . ", ";
				else
					$prepareStmt .= $getDataValues[$i];
			}
			$prepareStmt .= ")";
			$prepareStmt = $this->conn->prepare($prepareStmt);
			
			$dataVal = array();
			//binding params
			for($i=0; $i<$DataValuesSize; $i++) {
				$val[$i] = null;
				
				$prepareStmt->bindParam('' . $getDataValues[$i] . '', $dataVal[$i]);
			}
			
			$getArraySizeData = sizeof($getData[4]);
			for($z=0; $z<$getArraySizeData; $z++) {
				for($i=0; $i<$DataValuesSize; $i++) {
					$dataVal[$i] = $getData[$i][$z];
				}
				$prepareStmt->execute();
			}
			return 1;
		} catch(PDOExecption $e) {
			echo "<script>alert('Database Error : " . $e->getMessage() . "')</script>";
			return 0;
		}
	}
	
	public function checkData($istmt) {
		try {
			$returnBool = false;
			$this->connectDB();
			$data = $this->conn->query($istmt);
			foreach($data as $row) {
				$returnBool = true;
			}
			return $returnBool;
		} catch(PDOExecption $e) {
			echo "<script>alert('Database Error : " . $e->getMessage() . "')</script>";
			return 0;
		}	
	}

	public function query($stmt) {
		try {
			$this->connectDB();
			$this->stmt = $this->conn->prepare($stmt);
		} catch(PDOExecption $e) {
			echo "<script>alert('Database Error : " . $e->getMessage() . "')</script>";
			return 0;
		}
	}

	public function exec($param, $protectMode = true) {
		if($protectMode) 	$filterValues = filter_var_array($param, FILTER_SANITIZE_STRING);
		else 				$filterValues = $param;
		return				$this->stmt->execute($filterValues);
	}

	public function fetch() {
		return $this->stmt->fetchAll();
	}
}
?>




















