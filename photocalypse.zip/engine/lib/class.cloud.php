<?php

/*
	require : 	Cloudinary API class
			:	Database class
			:	config.php
*/

class Cloud {

	private $config = array( 
	  "cloud_name" => CLOUD_NAME, 
	  "api_key" => API_KEY, 
	  "api_secret" => API_SECRET
	);


	public function upload($file_url) {
		try {
			\Cloudinary::config($this->config);
			return \Cloudinary\Uploader::upload($file_url);
		}
		catch(exception $e) {
			echo "Your cloud is not responding " . $e;
		}
	}

	public function uploadDataUri($uri) {
		try {
			\Cloudinary::config($this->config);
			return \Cloudinary\Uploader::upload($uri);
		}
		catch(exception $e) {
			echo "Your cloud is not responding " . $e;
		}
	}
}
?>