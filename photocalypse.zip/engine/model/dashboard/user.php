<?php
if(isset($_GET['profile_id'])) {
	$profile_url = null;
	$lname = null;
	$fname = null;
	$country = null;
	$city = null;
	$description = null;
	$content = null;

	$con = new DB();
	$con->query("SELECT * FROM " . prefix . "profile WHERE id = :id LIMIT 1");
	$con->exec(array(
		":id" => $_GET['profile_id']
	));
	$data = $con->fetch();
	foreach($data as $row) {
		$profile_url = $row['profile_url'];
		$lname = $row['lname'];
		$fname = $row['fname'];
		$country = $row['country'];
		$city = $row['city'];
		$description = $row['description'];

		$con->query("SELECT  " . prefix . "post.id AS id, " . prefix . "post.post_views FROM " . prefix . "post," . prefix . "pp WHERE " . prefix . "pp.profile_id = :profile_id AND " . prefix . "pp.post_id = " . prefix . "post.id LIMIT 30");
		$con->exec(array(
			":profile_id" => $row['id']
		));
		$data = $con->fetch();
		foreach($data as $row) {
			$con->query("SELECT * FROM " . prefix . "media WHERE " . prefix . "media.post_id = :post_id LIMIT 30");
			$con->exec(array(
				":post_id" => $row['id']
			));
			$data2 = $con->fetch();
			foreach($data2 as $row2) {
				$content .= '
					<div class="col-lg-4 col-md-4 col-xs-12">
	                <div class="thumnbail-main">
	                  <a href="index.php?route=dashboard/post&post_id=' . $row2['id'] . '">
	                    <div class="thumbnail-wrap">
	                      <div class="thumbnail" style="background-image:url(' . $row2['url'] . ');">
                      </div>
	                      <div class="footer">
	                          <ul>
	                            <li><i class="far fa-eye"></i> ' . $row['post_views'] . '</li>
	                            <li><i class="far fa-comment"></i> 67</li>
	                            <li><i class="far fa-heart"></i> 789</li>
	                          </ul>
	                      </div>
	                    </div>
	                  </a>
	                </div>
	               </div>
				';
			}
		}
	}
	include("theme/dashboard/user.php");
}
else {
	include("theme/exception/404.php");
}
?>