<?php
try {
	$username = null;
	$fname = null;
	$lname = null;
	$occupation = null;
	$company = null;
	$description = null;
	$university = null;
	$country = null;
	$city = null;
	$profile_url = null;

	$con = new DB();
	$con->query("SELECT * FROM " . prefix . "profile WHERE id = :id LIMIT 1");
	$con->exec(array(
		":id" => $_SESSION['user']['id']
	));
	$data = $con->fetch();
	foreach($data as $row) {
		$username = $row['username'];
		$fname = $row['fname'];
		$lname = $row['lname'];
		$occupation = $row['occupation'];
		$description = $row['description'];
		$university = $row['university'];
		$country = $row['country'];
		$city = $row['city'];
		$profile_url = $row['profile_url'];
	}
	include("theme/dashboard/profile.php");
}
catch(exception $e) {
	echo $e;
}
?>