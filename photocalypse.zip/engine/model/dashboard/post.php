<?php
if(isset($_GET['post_id'])) {

	$title = null;
	$author_name = null;
	$created_on = null;
	$url = null;
	$description = null;
	$tags = array();
	$profile_url = null;


	$con = new DB();
	$con->query("SELECT " . prefix . "post.id, " . prefix . "post.title, " . prefix . "post.post_views, " . prefix . "post.description, " . prefix . "post.tags, " . prefix . "media.url, " . prefix . "post.created_on FROM " . prefix . "media, " . prefix . "post WHERE " . prefix . "media.id = :id AND " . prefix . "post.id = " . prefix . "media.post_id LIMIT 1");
	$con->exec(array(":id" => $_GET['post_id']));
	$data = $con->fetch();
	foreach($data as $row) {
		$con->query("SELECT " . prefix . "profile.id, " . prefix . "profile.profile_url, " . prefix . "profile.fname, " . prefix . "profile.lname, " . prefix . "profile.profile_url FROM " . prefix . "profile, " . prefix . "pp WHERE " . prefix . "pp.post_id = " . $row['id'] . " AND " . prefix . "pp.profile_id = " . prefix . "profile.id LIMIT 1");
		$con->exec(array(":id" => $_GET['post_id']));
		$data2 = $con->fetch();
		foreach($data2 as $row2) {
			$title = $row['title'];
			$author_name = ucwords($row2['fname'] . ' ' . $row2['lname']);
			$created_on = $row['created_on'];
			$url = $row['url'];
			$profile_url = $row2['profile_url'];
			$description = $row['description'];
			$tags = explode(",", $row['tags']);

			//update count views
			$row['post_views'] += 1;
			$con->query("UPDATE " . prefix . "post SET post_views = :post_views WHERE " . prefix . "post.id = :id LIMIT 1");
			$con->exec(array(
				":post_views" => $row['post_views'],
				":id" => $row['id']
			));

			foreach($tags as $tag) {
				$newTags[] = '<span class="badge badge-primary">' . $tag . "</span>";
			}
		}
	}
	include("theme/dashboard/post.php");
}
else {
	include("theme/exception/404.php");
}
?>