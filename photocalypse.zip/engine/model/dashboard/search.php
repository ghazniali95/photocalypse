<?php

try {
  $content = null;

  $con = new DB();
  $con->query("SELECT " . prefix . "media.url, " . prefix . "post.id AS id, " . prefix . "post.post_views, " . prefix . "media.id AS mId FROM " . prefix . "post," . prefix . "media WHERE " . prefix . "post.id = " . prefix . "media.post_id AND " . prefix . "post.tags LIKE '%" . $_GET['s'] . "%' ORDER BY post_views DESC LIMIT 30");
  $con->exec(array());
  $data = $con->fetch();
  foreach($data as $row) {
    $con->query("SELECT " . prefix . "profile.id, " . prefix . "profile.fname, " . prefix . "profile.lname FROM " . prefix . "pp," . prefix . "profile WHERE " . prefix . "pp.post_id = :post_id AND " . prefix . "pp.profile_id = " . prefix . "profile.id LIMIT 1");
    $con->exec(array(":post_id" => $row['id']));
    $data2 = $con->fetch();
    $content .= '
      <div class="col-lg-3 col-md-3 col-xs-12">
                  <div class="thumnbail-main">
                    <a href="index.php?route=dashboard/post&post_id=' . $row['mId'] . '">
                      <div class="thumbnail-wrap">
                        <div class="thumbnail" style="background-image:url(' . $row['url'] . ');">
                        </div>
                        <div class="footer">
                            <ul>
                              <li><i class="far fa-eye"></i> ' . $row['post_views'] . '</li>
                              <li><i class="far fa-comment"></i> 67</li>
                              <li><i class="far fa-heart"></i> 789</li>
                            </ul>
                        </div>
                      </div>
                    </a>
                    <p><a href="index.php?route=dashboard/user&profile_id=' . $data2[0]['id'] . '"> <i class="far fa-user-circle"></i> ' . ucfirst($data2[0]['fname']) . ' ' . ucfirst($data2[0]['lname']) . '</a></p>
                  </div>
                 </div>
    ';
  }
  include("theme/dashboard/search.php");
}
catch(exception $e) {
  echo $e;
}
?>