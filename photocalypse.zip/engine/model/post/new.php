<?php
include("theme/post/new.php");
?>