<?php
	include("theme/main/main.php");
?>