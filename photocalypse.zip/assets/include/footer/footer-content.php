<footer>
			<div class="container">
				<ul>
					<li style="font-size: 0.8em;"><?php echo $meta['sitename'] ?> &copy; 2018</li>
					<li><a href="how-it-work.php">How it works</a></li>
					<li><a href="#">Language</a></li>
					<li><a href="#">Careers</a></li>
					<li><a href="#">Privacy</a></li>
					<li><a href="#">Cookies</a></li>
					<li><a href="#">Terms</a></li>
					<li><a href="#">Help</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
			</div>
		</footer>

		<!--error handling-->
		<?php
			if(isset($_SESSION['error'])) {
				echo '
					<div style="    position: absolute;
    top: 70px;
    right: 9%;
    z-index: 10000000;" class="alert alert-danger" role="alert" >
					' . $_SESSION['error'] . '
			        </div>
				';
				unset($_SESSION['error']);
			}
			else if(isset($_SESSION['success'])) {
				echo '
					<div style="    position: absolute;
    top: 70px;
    right: 9%;
    z-index: 10000000;" class="alert alert-success" role="alert" >
						' . $_SESSION['success'] . '
			        </div>
				';
				unset($_SESSION['success']);
			}
		?>