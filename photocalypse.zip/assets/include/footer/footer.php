<?php defined("ACCESS") or die("Direct access is prohibited"); ?>
	
	<script type="text/javascript" src="assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="assets/js/popper.js"></script>
	<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
	
	

	<?php 
		echo $meta['footer_js'];
	?>