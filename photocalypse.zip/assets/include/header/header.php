<?php defined("ACCESS") or die("Direct access is prohibited"); ?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $meta['page_title'] . " - " . $meta['sitename'] ?></title>

	<!--header css bootstrap-->
	<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/fontawesome-all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">

	<?php 
		echo $meta['header_css'];
		echo $meta['header_js'];
	?>
</head>
<body class="<?php echo $meta['body_class']; ?>">