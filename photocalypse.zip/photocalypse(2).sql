-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 11, 2019 at 04:58 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `photocalypse`
--

-- --------------------------------------------------------

--
-- Table structure for table `cr_media`
--

CREATE TABLE `cr_media` (
  `id` bigint(20) NOT NULL,
  `post_id` int(11) NOT NULL,
  `public_id` text NOT NULL,
  `version` text NOT NULL,
  `width` text NOT NULL,
  `height` text NOT NULL,
  `format` text NOT NULL,
  `bytes` text NOT NULL,
  `url` text NOT NULL,
  `secure_url` text NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cr_post`
--

CREATE TABLE `cr_post` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `state` tinyint(1) NOT NULL,
  `visibility` tinyint(1) NOT NULL,
  `post_views` mediumint(9) NOT NULL,
  `tags` text NOT NULL,
  `thumbnail` varchar(200) NOT NULL,
  `og_title` text NOT NULL,
  `og_description` text NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cr_pp`
--

CREATE TABLE `cr_pp` (
  `profile_id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `cr_profile`
--

CREATE TABLE `cr_profile` (
  `id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(16) NOT NULL,
  `salt` varchar(128) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `email` varchar(75) NOT NULL,
  `phone` text NOT NULL,
  `profile_url` varchar(200) NOT NULL,
  `cover_url` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `occupation` text NOT NULL,
  `city` text NOT NULL,
  `country` text NOT NULL,
  `university` text NOT NULL,
  `created_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cr_media`
--
ALTER TABLE `cr_media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cr_post`
--
ALTER TABLE `cr_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cr_profile`
--
ALTER TABLE `cr_profile`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cr_media`
--
ALTER TABLE `cr_media`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cr_post`
--
ALTER TABLE `cr_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cr_profile`
--
ALTER TABLE `cr_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
