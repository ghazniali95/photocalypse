<?php
defined('ACCESS') or die("You do not have permission to access this page");
if(isset($_SESSION['user']['id']) && isset($_SESSION['user']['username'])) {
	if(isset($_GET['route'])) {
		try {
			$route = $_GET['route'];
			$meta['page_title'] = $route;
			include("engine/model/" . $route . ".php");
		}
		catch(exception $e) {
			
		}
	}
	else {
		include("engine/model/dashboard/dashboard.php");
	}
}
else {
	include("engine/model/main/main.php");
}

?>