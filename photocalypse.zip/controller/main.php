<?php
defined("ACCESS") or die("You do not have permission to access this page");

	if(isset($route[1])) {
		try {
			switch ($route[1]) {
				case 'main':
						include("theme/main.php");
					break;
				
				default:
						include("theme/main.php");
					break;
			}
		}
		catch(exception $e) {
			echo $e;
		}
	}
	else {
		include("engine/model/main/main.php");
	}
?>