<!DOCTYPE html>
<html>
   <head>
      <title>How it Works - Photocalypse</title>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <style type="text/css">
      .backgroud_image{
  height: 300px;
  width: 100%;

 background: linear-gradient(to bottom right, rgba(54,0,51,.7), rgba(11,135,147,.7)), url("media/images/a.JPEG");

  background-position: center;

}
.heading_style{

  text-align: center;
  height: 300px;
  line-height: 300px;
  font-size: 40px;
  color: white;
}
.main_image_section{

  vertical-align: middle;
  line-height: normal;
}
.working_image_class{
  width: 250px;
}
.heading_style1{
  margin-top: -120px;
}
.heading_cstly{
  text-decoration: none;
  color: white;

}
.heading_cstly:hover{
  background-color: #e73c28;
  transition: 1s;
  text-decoration: none;
  color: white;

}
#po{
  text-align: justify;
}</style>

   </head>
   <body>


<!-- NavBar -->
  <!--<nav class="navbar" class="navbar navbar-light bg-light justify-content-between">
    <div class="container">
        <a class="navbar-brand"><img src="media/images/logo.svg" width="200"></a>
        <form class="form-inline" method="POST" action="engine/protected/main/login_auth.php">
        <ul style="list-style-type: none;margin-top: 13px !important;" class="box1">
          <li><input name="username" placeholder="Username" required="" class="form-control mr-sm-2" type="text"></li>
          <li><label style="font-size: 10px; margin-left: -101px;
    margin-top: 5px;"><input type="checkbox" value="" style="width: 20px;">Remember Me</label></li>
        </ul> 

        <ul style="list-style-type: none; margin-top: 20px !important; "  class="box2">
          <li><input name="password" class="form-control mr-sm-2" placeholder="Password" required="" type="password"></li>
          <li><a href="" style="font-size: 10px;">Forgot Password?</a></li>
        </ul> 
          
          
          <button type="submit" name="login_auth" class="btn btn-photo" >Submit</button>
          
          <br />
        </form>
    </div>
  </nav>-->
    <section class="main_image_section">
        <div class="container_fluid backgroud_image">
          <center>
            <h1 class="heading_style">How It Works</h1>
            <p class="heading_style1"><a href="#home" class="heading_cstly">Home </a> <span style = "color:white;">/</span> <a href="#how_it_works" class="heading_cstly"> How It Works</a></p>
            <br>

          </center>
        </div>
    </section>

    <br><br>

    <section class="breefing_section">
      <div class="container">
        <div class="row">

          <div class="col-lg-6 col-md-6 col-xs-12">
            <center>
              <h3>People Make Their Photos Available To The People Who Matter To Them.</h3>
              <p id="po">Maybe they want to keep a blog of moments captured on their cameraphone, or maybe they want to show off their best pictures or video to the whole world in a bid for web celebrity. Or maybe they want to securely and privately share photos of their kids with their family across the country. Photocalypse makes all these things possible and more!</p>
            </center>

          </div>
          <div class="col-lg-6 col-md-6 col-xs-12">
            <center>
              <img src="media/images/bb.png" class="working_image_class">
            </center>
          </div>

        </div>
<br><br>
         <div class="row">

         <div class="col-lg-6 col-md-6 col-xs-12">
            <center>
              <img src="media/images/cc.png" class="working_image_class">
            </center>
          </div>

          <div class="col-lg-6 col-md-6 col-xs-12">
            <center>
              <h3>Enable New Ways Of Organizing Photos And Video</h3>
              <p id="po">Once you make the switch to digital, it is all too easy to get overwhelmed with the sheer number of photos you take or videos you shoot with that itchy trigger finger. Albums, the principal way people go about organizing things today, are great -- until you get to 20 or 30 or 50 of them.</p>
            </center>

          </div>
          

        </div>

        <br><br>

                <div class="row">

          <div class="col-lg-6 col-md-6 col-xs-12">
            <center>
              <h3>Making Ease For All The Users</h3>
              <p id="po">Part of the solution is to make the process of organizing photos or videos collaborative. In Photocalypse, you can Like, Follow, add comments, but also description and tags.Why not give them the ability to do this when they look at them over the internet? </p>
            </center>

          </div>
          <div class="col-lg-6 col-md-6 col-xs-12">
            <center>
              <img src="media/images/image_working.png" class="working_image_class">
            </center>
          </div>

        </div>
      </div>


    </section>

      <link rel="stylesheet" type="text/css" href="assets/css/style.css">
      <?php
      $meta['sitename'] = "Photocalypse";
      include("assets/include/footer/footer-content.php");
      ?>
   </body>
</html>