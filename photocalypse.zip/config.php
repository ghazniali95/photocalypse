<?php

	/*
		* Author : Ghazni Ali (ghazniali95@gmail.com, ali@mesh99.com)
		* Author : M Ammar Qureshi ()
		* Auhtor : Ahsan Raja ()

		* Date Created : 14-April-2018

		* Event : Nascon Web Development 24 hrs

		* Description : Photo Management App

		* Copyright : nil
	*/

		session_start();

		//access violation
		define("ACCESS", true);

		//////database configuration
		define('DB_DRIVER'    , 'mysql');   //Database driver
		define('DB_HOST'      ,   'localhost');   //Database host name
		define('DB_USERNAME'  ,   'root');        //Database username
		define('DB_PASSWORD'  ,   '');            //Database password
		define('DB_NAME'      ,   'photocalypse');   //Database name
		define('DB_PORT'      , '3306');

		//table prefix
		define("prefix", "cr_");

		//media cloud configuration
		define("CLOUD_NAME", "www-mesh99-com");
		define("API_KEY", "788757189299878");
		define("API_SECRET", "5yumoJeJZbx1Hcob8M9Nb75FsxI");

		//site configuration data
		$meta = array(
			"page_title" => "",
			"sitename" => "Photocalypse",
			"header_css" => "",
			"header_js" => "",
			"footer_css" => "",
			"footer_js" => "",
			"body_class" => ""
		);

?>