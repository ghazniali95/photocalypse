<?php
	include("assets/include/header/header.php");
?>

<section class="">
  <div class="container-fluid main_div">
    <div class="on_top_container">
    <center>
      <img src="">

      <h2 class="confirmation_heading_style"></h2>
    </center>
    </div>
    <center>
    <div class="container_top_div">
      <h2 class="head_ing">Error 404 Page Not Found !!!</h2>

    </div>
    </center>

  </div>
</section>
<br><br>
<section class="">
  <center>
    <h5>This Page might be broken we are very sorry for inconvenience!</h5>
    <br>
    <a href="index.php" class="btn btn-photo" name="verify">Go To Home</a>
  </center>
</section>