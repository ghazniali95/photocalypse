<?php
  include("assets/include/header/header.php");
  include("assets/include/header/header-content.php");
?>

<div class="container">
  <div class="col-sm-12">
    <section style="text-align: center;">
      <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist" style="max-width: 180px; margin:0 auto;">
        <li class="nav-item">
          <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-expanded="true">Content</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-expanded="true">Finish</a>
        </li>
      </ul>
    </section>

  </div>
  <form id="new_post" method="POST" action="engine/protected/post/new.php" enctype="multipart/form-data">
  <div class="col-sm-12">
    <h3>Title</h3>
    <div class="row">
      <div class="form-group col-md-12">
        <input type="text" class="form-control" name="title" id="inputEmail4" placeholder="Email" required>
      </div>

      <!--<div class="form-group col-md-6">
        <label><input type="radio" class="form-control" name="state" id="inputEmail4" placeholder="Email" required checked="checked"> Public</label>

        <label><input type="radio" class="form-control" name="state" id="inputEmail4" placeholder="Email" required> Private</label>
      </div>-->

      <div class="col-lg-12 col-md-12 col-sm-12"><output id="list"></output></div>

      <div class="form-group col-md-12">
        <input style="height: 200px" type="file" id="files" name="files[]" class="form-control" multiple />
      </div>

      <div class="form-group col-md-6">
        <textarea class="form-control" name="description" placeholder="Description"></textarea>
      </div>

      <div class="form-group col-md-6">
        <textarea class="form-control" name="tags" placeholder="Tags" required=""></textarea>
      </div>
    </div>
  </div>
  <div class="col-sm-12">
    <button type="submit" name="upload_post" class="btn btn-outline-info">Save</button>
    <button type="button" class="btn btn-outline-success">Continue</button>
  </div>
</form>
<script>

  function handleFileSelect(evt) {
    var files = evt.target.files; // FileList object
    // Loop through the FileList and render image files as thumbnails.
    for (var i = 0, f; f = files[i]; i++) {

      // Only process image files.
      if (!f.type.match('image.*')) {
        continue;
      }

      var reader = new FileReader();

      // Closure to capture the file information.
      reader.onload = (function(theFile) {
        return function(e) {
          // Render thumbnail.
          var span = document.createElement('span');
          span.innerHTML = ['<img class="thumb" src="', e.target.result,
                            '" title="', escape(theFile.name), '"/>'].join('');
          document.getElementById('list').insertBefore(span, null);
        };
      })(f);

      // Read in the image file as a data URL.
      reader.readAsDataURL(f);
    }
  }

  document.getElementById('files').addEventListener('change', handleFileSelect, false);
</script>



</div>
<?php
    include("assets/include/footer/footer-content.php");
    include("assets/include/footer/footer.php");
?>