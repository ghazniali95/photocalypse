<?php
	echo "Just in case if you are using it on localhost you will not get any mail so you can look for the code here just for testing purpose : " . $_SESSION['vcode'];
	include("assets/include/header/header.php");
?>




<section class="">
  <div class="container-fluid main_div">
    <div class="on_top_container">
    <center>
      <img src="">

      <h2 class="confirmation_heading_style"></h2>
    </center>
    </div>
    <center>
    <div class="container_top_div">
      <h2 class="head_ing">Verification Email Sent !!!</h2>

    </div>
    </center>

  </div>
</section>
<br><br>
<section class="">
  <center>
    <h5>Thank You For Signing Up For Your New Account At Photocalypse</h5>
    <p>Confirmation Email has heen Sent at your Email Address</p>
    <br>
    <div class="row">
    	<div class="col-lg-4"></div>
    	<div class="col-lg-4">
    		<form method="POST" action="engine/protected/main/verify.php">
				<div class="form-group col-md-12">
					<label>Enter your verification code here.</label>
					<input type="text" class="form-control" name="vcode" placeholder="Verification Code" style="margin-bottom:20px;">
					<button class="btn btn-photo" type="submit" name="verify">Verify</button>
				</div>
			</form>
    	</div><div class="col-lg-4"></div>
    </div>
  </center>
</section>