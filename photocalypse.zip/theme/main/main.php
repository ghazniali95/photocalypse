<?php
	include("assets/include/header/header.php");
?>
<!-- NavBar -->
	<nav class="navbar" class="navbar navbar-light bg-light justify-content-between">
		<div class="container">
				<a class="navbar-brand"><img src="media/images/logo.png" width="200"></a>
				<form class="form-inline" method="POST" action="engine/protected/main/login_auth.php">
				<ul style="list-style-type: none;margin-top: 13px !important;" class="box1">
					<li><input name="username" placeholder="Username" required="" class="form-control mr-sm-2" type="text"></li>
					<li><label style="font-size: 10px; margin-left: -101px;
    margin-top: 5px;"><input type="checkbox" value="" style="width: 20px;">Remember Me</label></li>
				</ul>	

				<ul style="list-style-type: none; margin-top: 20px !important; "  class="box2">
					<li><input name="password" class="form-control mr-sm-2" placeholder="Password" required="" type="password"></li>
					<li><a href="" style="font-size: 10px;">Forgot Password?</a></li>
				</ul>	
					
					
					<button type="submit" name="login_auth" class="btn btn-photo" >Submit</button>
					
					<br />
				</form>
		</div>
	</nav>

		<!-- Sign Up Part -->
		<section id="main-wrap">
			<div class="container">
				<div class="row">
					<!-- Left Side Row -->
					<div class="col-lg-6 col-md-6 col-xs-12">
						<div class="banner">
							<h1 class="upper color_photo">
								<?php echo $meta['sitename']; ?>
							</h1>

							<h4 class="">Show Photo Graphs</h4>  

							<p>
								Lorem ipsum is a dummy text used in print media and other ipsum is a dummy text used in print media and othes 
							</p> 
						</div>
					</div>

					<!-- Right Side Row -->
					<div class="col-lg-6 col-md-6 col-xs-12">
						<div class="well" style="max-width: 22em;">
							<h4 class="form-heading">
								Sign Up
							</h4>
							<form method="POST" action="engine/protected/main/main.php" enctype="multipart/form-data">
								<input type="hidden" name="profileData" id="profile_pic" value="" />
								<div id="wrap1" class="take-pic">
									<p>First things first start with your profile picture</p>
									<video style="margin-left: 45px" class="video-wrap" id="video"></video>
									<canvas class="hidden" id="canvas"></canvas><br>
									<div style="width: 100%; background-color: transparent;" id="image"></div>
									<button id="take_pic" onclick="snap()" type="button" class="btn btn-photo btn-block" name="register">Take Picture</button>
									<div class="row">
										<div class="col-lg-8 col-md-12 col-sm-12">
											<button id="next" type="button" class="btn btn-photo btn-block hidden" name="register">Happy! Next Step</button>
										</div>
										<div class="col-lg-4 col-md-12 col-sm-12">
											<button id="reset" type="button" class="btn btn-default btn-block hidden" name="register">Reset</button>
										</div>
									</div>
								</div>
								<div id="wrap2" class="row hidden">
									<input id="profile_data" type="hidden" name="profile" value="">
										<div class="form-group col-md-6 col-lg-6" >
											<input type="text" class="form-control" name="fname" id="formGroupExampleInput" placeholder="First Name" required>
										</div>
										<div  class="form-group col-md-6 col-lg-6" >
											<input type="text" class="form-control" name="lname" id="formGroupExampleInput" placeholder="Last Name" required>
										</div>

									<div class="form-group col-md-12">
										<input type="email" class="form-control" name="email" id="inputEmail4" placeholder="Email" required>
									</div>

									<div class="form-group col-md-12">
										<input type="text" class="form-control" name="phone" id="formGroupExampleInput2" placeholder="Phone No">
									</div>

									<div class="form-group col-md-12">
										<input type="text" class="form-control" name="username" id="formGroupExampleInput2" placeholder="Username" required>
									</div>

									<div class="form-group col-md-12">
										<input type="password" class="form-control" name="password" id="inputPassword4" placeholder="Password" required>
									</div>
									<div class="form-group col-md-12">
										<button type="submit" class="btn btn-photo btn-block" name="register">Sign Up</button>
									</div>
								</div>
							</form>
						</div>
						<div class="well" style="max-width: 22em;">
								<div>
									<p style="padding: 0px; margin: 0px;">Make a quick account from following</p>
								</div>
						</div>
						<div class="well" style="max-width: 22em; background: transparent; box-shadow: none;">
							<h4 class="form-heading" style="color: white">
								Use Social Power
							</h4>
							<div class="row">
								<div class="col-lg-6 col-md-6 col-xs-12">
									<button id="btn-facebook" type="submit" class="btn btn-primary btn-block">Facebook Login</button>
								</div>
								<div class="col-lg-6 col-md-6 col-xs-12">
									<button id="btn-gmail" type="submit" class="btn btn-primary btn-block">Gmail Login</button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>


		<!-- Top Photographers -->

		<section class="center-wrap">
			<div class="container">
				<h2>How it works</h2>
				<p>Our highly creative community where you can upload share and review any images easily integrated with high speed <b>cloud support</b> and <b>Face Detection</p></p>
			</div>
			
			<div class="row">
				<div class="col-lg-3 col-md-2 col-xs-12"></div>
				<div class="col-lg-6 col-md-8 col-xs-12">
					<video style="    width: 100%;
    min-height: 420px;" controls autoplay loop>
					  <source src="media/videos/photocalypse.mp4" type="video/mp4">
					  <source src="movie.ogg" type="video/ogg">
					  Your browser does not support the video tag.
					</video>
				</div>
				<div class="col-lg-3 col-md-2 col-xs-12"></div>
			</div>
		</section>



		
		<!-- Here Pictures Will Be Added -->
		<?php
		include("assets/include/footer/footer-content.php");
		include("assets/include/footer/footer.php");
		?>
		<script type="text/javascript">
			$("#next").click(function () {
				//alert("sf");
				$("#wrap2").fadeIn(200);
				$("#wrap1").fadeOut(500);
			});

			$("#reset").click(function () {
				$("#image").hide();
				$("#video").show();
				$(this).hide();
				$("#next").hide();
				$("#take_pic").show();
			})
		</script>

<script type="text/javascript">
	var video = document.getElementById('video');
	var canvas = document.getElementById('canvas');
	var context = canvas.getContext('2d');
      var x = 288;
      var y = 30;
      var width = 100;
      var height = 187;

	navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.oGetUserMedia || navigator.msGetUserMedia;

	if(navigator.getUserMedia){
		navigator.getUserMedia({video:true}, streamWebCam, throwError);
	}
	function streamWebCam (stream){
		video.src = window.URL.createObjectURL (stream);
		video.play();
	}
	function throwError(e){
		alert(e.name);
	}
	function snap(){
	    canvas.width = video.clientWidth;
	    canvas.height = video.clientHeight;
	    context.drawImage(video, 0,0, canvas.width, canvas.height);
	    console.log("start");
	    $("#video").hide();
	    $("#take_pic").hide();
	    $("#next").show();
	    $("#reset").show();
		var element = document.getElementById("image");
		element.className = "image_paste";
		element.appendChild(convertCanvasToImage(canvas));
	}

	function convertCanvasToImage(canvas) {
		var image = new Image();
		image.src = canvas.toDataURL("image/png");
		console.log(image.src);
		$("#profile_pic").val(image.src);
		console.log(image);
		return image;
	}
  </script>

	</body>
</html>