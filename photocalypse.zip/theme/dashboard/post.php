<?php
  include("assets/include/header/header.php");
  include("assets/include/header/header-content.php");
?>
<section>
<div class="container">
	<h3><?php echo ucwords($title) ?></h3>
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-12">
			<img style="width: 100%" src="<?php echo $url ?>">
		</div>

		<div class="col-lg-4 col-md-4 col-xs-12">
			<div class="media">
			  <div class="media-left">
			    <img src="<?php echo $profile_url ?>" class="media-object head-prof" style="width:85px; height:85px; margin-right:10px;">
			  </div>
			  <div class="media-body">
			    <h5 style="margin:0px;" class="media-heading"><?php echo $author_name; ?></h5>
			    <p><small><i class="far fa-clock"></i> <?php echo $created_on ?></small><br /><button type="button" style="margin-top: 5px;" class="btn btn-outline-primary btn-sm ">Follow</button></p>
			  </div>
			</div>

			<div class="inline-icons">
                          <ul>
                            <li><i class="far fa-eye"></i> 678</li>
                            <li><i class="far fa-comment"></i> 67</li>
                            <li><i class="far fa-heart"></i> 789</li>
                          </ul>
                      </div>
                      <hr />
                      <h5>Description</h5>
                      <p><?php echo $description ?></p>
                      <h5>Tags</h5>
                      <p><?php echo implode(" ", $newTags) ?></p>

			<hr />
			<h5>Share on:</h5>
			<div class="inline-icons">
                          <ul style="font-size: 1.8em">
                            <li><i class="fab fa-facebook"></i></li>
                            <li><i class="fab fa-twitter-square"></i></li>
                            <li><i class="fab fa-google-plus-square"></i></li>
                          </ul>
                      </div>
		</div>
	</div>



<div class="row">
	<div class="col-lg-8 col-md-8 col-xs-12">
 			<h5 style="margin: 20px 0px">Write a comment</h5>
 			<div class="form-group">
 			<textarea  class="form-control" placeholder="Enter Comment From Here"></textarea>
 			</div>
 			<button  class="btn btn-photo">Post A Review</button>
 			<br>
 			<hr>

 			<div class="media">
			  <div class="media-left">
			    <img src="img_avatar1.png" class="media-object head-prof" style="margin-right: 10px; width:60px height:60px;">
			  </div>
			  <div class="media-body">
			    <h4 class="media-heading">Ahsan Raja</h4>
			    <p>Nice Photo you must be from comsats wah?</p>
			  </div>
			</div>
 			<hr>
 			<div class="media">
			  <div class="media-left">
			    <img src="img_avatar1.png" class="media-object head-prof" style="margin-right: 10px; width:60px height:60px;">
			  </div>
			  <div class="media-body">
			    <h4 class="media-heading">Ammar Qureshi</h4>
			    <p>I like this photo</p>
			  </div>
			</div>
	</div>

	<div class="col-lg-3 col-md-3 col-xs-12">
	</div>
	</div>
	



</div>
</section>
<?php
    include("assets/include/footer/footer-content.php");
    include("assets/include/footer/footer.php");
?>