<?php
  include("assets/include/header/header.php");
  include("assets/include/header/header-content.php");
?>
	<section>
		<div class="container">
			<div class="row">
				<div class="col-lg-2 col-lg-3 col-sm-12">
					<div class="card">
					<div class="card-header">
						<b>Settings</b>
						  </div>
						  <ul class="list-group list-group-flush">
						    <li class="list-group-item">Change About me from here, upload profile picture, update profile, when you update your profile your chances of being viewed are higher.</li>
						  </ul>
						</div>
					</div>


					<div class="col-lg-8 col-md-9 col-sm-12">
					<p>Face Detection is implemented here if you will upload more than one faces the image will not upload as your profile should have only one face and that should be you.</p>
					<?php
						if(isset($_SESSION['imageDet'])) {
							echo '<div class="alert alert-info">
								Uploaded Image Details: <br />';
							echo "Gender: ";
						print_r($_SESSION['imageDet'][0]['faceAttributes']['gender']);
						echo "<br />";
						echo "Age: ";
						print_r($_SESSION['imageDet'][0]['faceAttributes']['age']);
						echo '
							</div>';
						}
					?>
						<form method="POST" action="engine/protected/dashboard/profile.php" enctype="multipart/form-data">
						<div class="row">
							<div class="col-lg-3 col-sm-3">
								<div class="form-group">
									<img src="<?php echo $profile_url ?>" style="width: 100%;">
								</div>
								<div class="form-group">
									<input class="form-control" type="file" name="profile">
								</div>
							</div>

							<div class="col-lg-9 col-sm-9">
										<div>

											<div class="form-group">
												<label >Username</label>
												<input type="text" class="form-control" value="<?php echo $username ?>" disabled="">
											</div>
											<p style="text-align: center;">Reset Password</p>
											<div class="form-row">
												<div class="form-group col-md-6">
													<label>New Password</label>
													<input name="newpass" type="password" class="form-control" name="fname">
												</div>
												<div class="form-group col-md-6" >
													<label>New Password Again</label>
													<input name="newpassagain" type="password" class="form-control" name="fname">
												</div>
											</div>
											<div class="form-row">

												<div class="form-group col-md-6" >
													<label>First Name</label>
													<input name="fname" type="text" class="form-control" value="<?php echo $fname ?>">
												</div>
												<div class="form-group col-md-6" >
													<label>Last Name</label>
													<input name="lname" type="text" class="form-control" value="<?php echo $lname ?>">
												</div>
											</div>
											<div class="form-group">
												<label>Occupation</label>
												<input name="occupation" type="text" class="form-control"  value="<?php echo $occupation ?>">
											</div>
											<div class="form-group">
												<label >Company</label>
												<input name="company" type="text" class="form-control" value="<?php echo $company ?>">
											</div>
											<div class="form-group">
												<label >Description</label>
												<textarea name="description" class="form-control"><?php echo $description ?></textarea>
											</div>
											<div class="form-row">
												<div class="form-group col-md-12" >
													<label>University</label>
													<input type="text" class="form-control" name="university" value="<?php echo $university ?>">
												</div>
											</div>
											<div class="row">
												<div class="form-group col-md-6">
													<label >Country</label>
													<select name="country" class="form-control">
														<option value="<?php echo $country ?>"><?php echo $country ?></option>
														<option value="0">Choose...</option>
														<option value="pakistan">Pakistan</option>
													</select>
												</div>
												<div class="form-group col-md-6">
													<div >
														<label for="inputCity">City</label>
														<input name="city" type="text" class="form-control" value="<?php echo $city ?>">
													</div>
												</div>
											</div>
											<button name="update_prof" class="btn btn-photo btn-block">Update</button>

								</div>
							</div>
						</form>





						</div>

					</div>

				</div>

			</div>
		</div>
		


	</section>
<?php
    include("assets/include/footer/footer-content.php");
    include("assets/include/footer/footer.php");
?>