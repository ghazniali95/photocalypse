<?php
  include("assets/include/header/header.php");
  include("assets/include/header/header-content.php");
?>
<section id="cover-wrap">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-4 col-sm-12">
				<div class="well" style="text-align: center;">
					<div style="text-align: center; margin-bottom: 20px;">
						<img src="<?php echo $profile_url ?>" class="head-prof" style="width: 100px; height:100px;" />
					</div>
					<h4><?php echo ucwords($fname . " " . $lname) ?></h4>
					<p><small><?php echo $city . ", " . $country ?></small><br />
						<?php echo $description ?></p>
						<div class="row">
							<div class="col-lg-12 col-md-12 col-sm-12" style="text-align: center;">
								<button class="btn btn-outline-photo">Follow</button>
							</div>
						</div>
				</div>
			</div>
			<div class="col-lg-8 col-md-4 col-sm-12">
				<div class="row">
					<?php echo $content; ?>
				</div>
				<div class="row">
		          <div class="col-lg-4 col-md-4 col-xs-12"></div>
		          <div class="col-lg-4 col-md-4 col-xs-12">
		            <div class="alert alert-secondary" role="alert" style="text-align: center; margin-top:100px;">
		              No More Images to Load!
		            </div>
		          </div>
		          <div class="col-lg-4 col-md-4 col-xs-12"></div>
		        </div>
			</div>
		</div>
	</div>
</section>
<?php
    include("assets/include/footer/footer-content.php");
    include("assets/include/footer/footer.php");
?>