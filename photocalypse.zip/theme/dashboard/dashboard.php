<?php
  include("assets/include/header/header.php");
  include("assets/include/header/header-content.php");
?>

      <section>
         <div class="container">
            <div class="row">

              <?php echo $content; ?>
               
               
            </div>
         </div>
      </section>
      <div class="container">
        <div class="row">
          <div class="col-lg-4 col-md-4 col-xs-12"></div>
          <div class="col-lg-4 col-md-4 col-xs-12">
            <div class="alert alert-secondary" role="alert" style="text-align: center;">
              No More Images to Load!
            </div>
          </div>
          <div class="col-lg-4 col-md-4 col-xs-12"></div>
        </div>
      </div>
<?php
    include("assets/include/footer/footer-content.php");
    include("assets/include/footer/footer.php");
?>